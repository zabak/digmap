#!/bin/sh


CONTENTS=../../DATA/INDEXES/contents/
TEXT_TEMP_GEO_DB=../../DATA/INDEXES/GEO_TEMP_INDEXED/
POOL=poolExample.xml

LGTE_DIR=.

##################################

BASE_LGTE=$LGTE_DIR
CLASSES_LGTE=$BASE_LGTE/WEB-INF/classes
LIB_LGTE=$BASE_LGTE/WEB-INF/lib
LIBS_LGTE=

for i in `ls $LIB_LGTE`; do
LIBS_LGTE=$LIB_LGTE/$i:$LIBS_LGTE
done


java -Xmx1500m -Xms800m -XX:PermSize=256m -XX:MaxPermSize=512m -server -classpath "$CLASSES_LGTE:$LIBS_LGTE" pt.utl.ist.lucene.web.assessements.services.Server $POOL NtcirGeoTime2011 $TEXT_TEMP_GEO_DB $CONTENTS



